package pl.jkan.creditcard;

class CreditCard {
    public double getBalance() {
        return 2000;
    }
    
    public void assignLimit(double limit) {
        
    }
}